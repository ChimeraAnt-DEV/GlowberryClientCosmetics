# Credits

Hat models in this folder are converted from the **Minecraft Hats Mini-pack 1-5** series by **VoxelBear** on Sketchfab
(https://sketchfab.com/VoxelBear/models), made in Blockbench.

Licence: Creative Commons Attribution (CC BY), as shown on the Mini-pack 3 page. Mini-packs 1, 2, 4 and 5 are by the same
author; confirm each page shows the same licence before shipping.

Changes made: converted from glTF to Bedrock `.geo.json` (per-face UVs kept), split into one file per hat, and re-aimed
so the front faces -Z and the hat sits on a head whose top is at y=32. Textures are unchanged.
